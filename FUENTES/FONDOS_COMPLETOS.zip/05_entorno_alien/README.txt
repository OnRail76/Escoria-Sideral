05_entorno_alien
256x48, 1 bit. 1536 bytes bitmap lineal. 192 tiles únicos. SCR de prueba en Y=16. Usar bitmap O tiles+mapa; no duplicarlos en RAM. Fondo fijo sin colisión. Restaurar el fondo al borrar sprites. ASM de datos, no rutina.
